#!/bin/sh

python3 ../tests/run.py $1
